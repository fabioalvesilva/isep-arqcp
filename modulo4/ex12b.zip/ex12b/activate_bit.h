#ifndef activate_bit
#define activate_bit

int activate_bit(int *ptr, int pos);

#endif
