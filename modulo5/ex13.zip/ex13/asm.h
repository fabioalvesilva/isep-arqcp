#ifndef ASM_H
#define ASM_H

int count_odd_matrix(int **m, int y, int k);
int **new_matrix(int y, int k);
void fill_matrix(int **m, int y, int k);
void print_matrix(int **m, int y, int k);


#endif
